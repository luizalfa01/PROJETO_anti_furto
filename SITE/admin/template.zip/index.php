<?php
	include "templete/topo.php";
?>
<center><h1>PAGINA INICIAL</h1></center>
<?php
	include "templete/rodape.php";
?>