<html>
	<head>
		<meta charset="utf-8"/>
		<title>ANTI FURTO</title>
		<link rel="stylesheet" type="text/css" href="css/css.css" />

	</head>
	<body>
		
		<div id = "header">
			<table width="100%">
				<tr><th width="35%"><h1 class = "titulo">ANTI FURTO COMPANY</h1></th>
				<th width="20%"></th>
				<th width="35%"><form method="POST" action=""><table><tr><th><input class ="form" type="text" size="20px"></th><th><button type="submit" class="botao1"><img src="lupa.png" style="width:24px;"></button></th></tr></table></form></th></tr>
			</table>
		</div><!-- /header-->
		
		<div id = "nav">
			<table class="tablelinks" width="100%">
				<tr><th><a class="link" href="index.php">INICIO</a></th>
				<th><a class="link" href="produtos.php">PRODUTOS</a></th>
				<th><a class="link" href="clientes.php" >CLIENTES</a></th>
				<th><a class="link" href="fornecedor.php" style="font-size:15px; margin-left:35px">FORNECEDOR</a></th>
				<th><a class="link" href="pedidos.php">PEDIDOS</a></th>
				<th><a class="link" href="cadastro.php" style="font-size:15px">CADASTRO</a></th></tr>
			</table>
		</div><!-- /nav-->
		
		<center><img src ="logo.png" style="position:fixed; right: 46.5%;"></center>
		
		<div id="wrapper">
			
			<div id = "suport">
			</div><!-- /suport-->
			
			<div id = "content">
				<?php
					include "conexao/conecta.php";
				?>